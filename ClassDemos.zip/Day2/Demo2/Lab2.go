package main

import "fmt"
import "encoding/json"

type MyJsonObject struct {
	Page       int `json:"page"`
	PerPage    int `json:"per_page"`
	}
	
func main() {	
	myobj := MyJsonObject{1,12}
	barr,err :=json.Marshal(myobj)
	if (err == nil) {
		fmt.Println(string(barr))
	}
	str := "{\"page\": 1111, \"per_page\":4333}"
	res := MyJsonObject{}
	fmt.Println("Original Object ", res)
	json.Unmarshal([]byte(str), &res)
	fmt.Println("After UnMarshal  ", res)
}