package main
import ("fmt"	
"net/http"	
"io/ioutil")
func main() { 
	url :="https://reqres.in/api/users/2"    
	var client = http.Client{} 
	resp, err := client.Get(url); 
	if err != nil {	
		fmt.Println("Error " );
	} else {
		fmt.Println("resp" , resp);	
		data, _ := ioutil.ReadAll(resp.Body)
		fmt.Println("\n\n\nbody " ,string(data)) 
	}
}
