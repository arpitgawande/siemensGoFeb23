package main
import(
	"fmt"
	"time"
	"sync"
)
type Bank struct{
	bal int
}
func incr(bank *Bank){
	for i:=1;i<=500;i++{
		mutex.Lock()
		curbal := bank.bal
		curbal++
		bank.bal = curbal
		mutex.Unlock()
		}
}
func decr(bank *Bank){
	for i:=1;i<=500;i++{
		mutex.Lock()
		curbal := bank.bal
		curbal--
		bank.bal = curbal
		mutex.Unlock()
	}
}
func print(str string ){
	for i:=1;i<=5;i++{
		fmt.Println(str , i)
		names = append(names, str)
	}
	fmt.Println("For ", str , " , current names ", names)
}
var mutex sync.Mutex 
var names []string
func main(){
	
	names =  make([]string, 0)  
	fmt.Println("main start")
	go print("hello")
	fmt.Println("main end")
	
	fmt.Println("Current length of names is " , len(names))
	b1 := Bank{0}
	go incr(&b1)
	go decr(&b1)
	time.Sleep(5 * time.Second)
	fmt.Println("Current Balance = ", b1)
	time.Sleep(5 * time.Second)
	fmt.Println("Current Balance = ", b1)
	time.Sleep(5 * time.Second)
	fmt.Println("Current Balance = ", b1)

}