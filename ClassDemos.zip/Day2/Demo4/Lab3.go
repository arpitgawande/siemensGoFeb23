package main

import (
	"fmt"
	"time"
)

func main() {
	fmt.Println("Starting of main")
	ch := make(chan int)
	fmt.Println("ch", ch)
	go read(ch)
	go write(ch)
	time.Sleep(10 * time.Second)
	fmt.Println("Main over...")
}
func read(ch chan int) {
	fmt.Println("Reading Started")
	v := <-ch
	fmt.Println("Read from channel - ", v)
	fmt.Println("Reading  Completed1")
	for {
		v = <-ch
		fmt.Println("Reading  ", v)
		// this will not allow program to complete
	}
	fmt.Println("Reading  Completed2")
}
func write(ch chan int) {
	fmt.Println("Writing Started")
	ch <- 10
	ch <- 11
	ch <- 12
	ch <- 13
	ch <- 14

	fmt.Println("Writing Completed")
}
