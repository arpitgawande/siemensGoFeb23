package main
import (
	"fmt"
     "os"
	)
func main(){
	fmt.Println("Len Args = " , len(os.Args))
	for i:=0 ;i<len(os.Args);i++{
		fmt.Println(os.Args[i], " , " , len(os.Args[i]))
	}
}