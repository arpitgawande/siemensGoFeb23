/*
	Write a function for swapping two string values 
    Write a function to accept String and return length of String
*/
package main
import "fmt"
func main(){
	strlen("aaaaaa")
	x, y := swap("abc", "xyz")
	fmt.Println(x, y)
}
func swap(x, y string)(string,string){
	return y,x
}
func strlen(x string) int {
	fmt.Println("leng " , len(x))
	return len(x)
}
