package main
import "fmt"
import "sort"

func main(){
/*	fmt.Println("Enter your name")
	str := "aa"
	x, err:= fmt.Scanln(&str)
	fmt.Println("x = " , x , ", Error = ", err)
	fmt.Println("Hello, " , str);
*/
	//printfib()
	printarr()
}
func printarr(){
	//Accept 5 strings from user and sort and print the same
	var arr [5]string
	for i:=0;i<5;i++ {
		fmt.Print("Enter String :")
		fmt.Scanln(&arr[i])
	}
	fmt.Println(arr)
	sort.Strings(arr[:])
	fmt.Println(arr)
}

//Accept a number from user and print Fibonacci series till that number
func printfib(){
	var count int
	fmt.Println("Enter  a number ")
	fmt.Scanln(&count)
	no1, no2 := 0,1
	fmt.Print( no1 ," , " , no2)
	no3 := no1+no2
	for (no3 < count){
		fmt.Print(" ,  " , no3)
		no1, no2 = no2, no3
		no3  = no1+no2
	}
}
