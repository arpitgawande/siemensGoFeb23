package main
import "fmt"
type Point struct {
	x int
	y int
}
func incr(point *Point){
	point.x +=10
	point.y +=10
	fmt.Println("in incr" , point)
}
func (point *Point) incr2(x, y int){
	point.x +=x
	point.y +=y
	fmt.Println("in incr222" , point)
}
func main(){
	v1 := Point{10,20}
	fmt.Println(v1)
	v1 = Point{y:10,x:20}
	fmt.Println(v1)
	incr(&v1)
	fmt.Println(v1)
	v1.incr2(2,6)
	fmt.Println(v1)
}