package main
import (
	"fmt"
	
)

func main(){
	primes := []int{20, 31, 55, 77, 1, 13}
	fmt.Println(primes)
	//sort.Sort(sort.IntSlice(primes))
	//fmt.Println(primes)
	var s []int = primes[1:4]
	fmt.Println(s)
	s[0] = 1000
	fmt.Println(s)
	s = primes[:3]
	fmt.Println(s)
	s = primes[3:5]
	fmt.Println(s)

	

}