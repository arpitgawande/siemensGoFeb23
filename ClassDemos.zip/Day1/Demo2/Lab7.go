package main

import (
    "log"
    "os"
    "io"
)

func main() {
    fi1, err1 := os.Open(os.Args[1])
    if err1 != nil {
        log.Fatal("FileInput - " , err1)
    }
	defer fi1.Close()
    fi2, err1 := os.Open(os.Args[2])
    if err1 != nil {
        log.Fatal("FileInput - " , err1)
    }
	defer fi2.Close()

    fo, err2 := os.OpenFile(os.Args[3], os.O_RDWR|os.O_CREATE, 0755)
	defer fo.Close()
    if err2 != nil {
        log.Fatal("FileOutput  - ", err2)
    }
    appendfile(fi1, fo)
    appendfile(fi2,fo)
}
func appendfile(input *os.File, output *os.File){
    buf := make([]byte, 1024)
    for {
        // read a chunk
        n, err3 := input.Read(buf)
	    if err3 != nil && err3 != io.EOF {
            log.Fatal(err3)
        }
        if n == 0 {
            break
        }
       // write a chunk
        if _, err4 := output.Write(buf[:n]); err4 != nil {
            log.Fatal(err4)
        }
    }
    }

