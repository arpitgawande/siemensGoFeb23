package main
import (
	"fmt"
 	//"strconv"
)

type Emp struct {
	Empno  int 
	Ename  string 
	Salary int 
}
func (emp *Emp) incrSal(percent int){
	emp.Salary += emp.Salary* percent/100
}
func (emp Emp) print(){
	fmt.Println("Print EmpNo = " , emp.Empno , " , Ename =" , emp.Ename + ", Salary = " , emp.Salary)
}
type EmpManager struct {
	emparr []Emp 
}
func (empmgr *EmpManager) add(e1 Emp){
	empmgr.emparr = append(empmgr.emparr, e1)
}
func (empmgr *EmpManager) delete(empno int){
	for i,v := range(empmgr.emparr){
		if (v.Empno == empno){
			fmt.Println("Found Matching Emp")
			empmgr.emparr = append(empmgr.emparr[0:i], empmgr.emparr[i+1:]...)
	/*		tmp :=empmgr.emparr[0:i]
			for cnt:=i+1 ;cnt < len(empmgr.emparr);cnt++{
				tmp = append(tmp, empmgr.emparr[cnt])
			}
			empmgr.emparr = tmp
	*/
			break
		}
	}
}
func (empmgr EmpManager) print(){
	for i,v := range(empmgr.emparr){
		fmt.Println("i = ", i , " Value = ", v)
	}
}


func main() {

	empmgr := EmpManager{}
	emp := Emp{1,"One",111}
	empmgr.add(Emp{2,"Two",222})
	
	empmgr.add(emp)
	e1 := Emp{5,"Three", 0}
	fmt.Println("Enter salary for Emp number 3")
	sal :=0
	fmt.Scanln(&sal)
	//sal1 := "400"
	//e1.Salary,_ = strconv.Atoi(sal1)
	e1.Salary  = sal
	fmt.Println(e1)
	empmgr.add(e1)
	fmt.Println(empmgr)
	empmgr.print()
	empmgr.delete(1)
	empmgr.print()
	
}	