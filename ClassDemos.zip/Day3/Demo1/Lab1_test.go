package main

import "testing"
import "fmt"
func TestAdd2(t *testing.T) {
    got := add(10,100)
    if got != 110 {
        t.Errorf("Add(10,100) = %d; want 110", got)
    }
}

func TestDivide1(t *testing.T){
	got,_:= divide("100","10")
    if got != 10 {
        t.Errorf("Divide(100,10) = %d; want 10", got)
    }
}
/*
func TestDivide2(t *testing.T){
	defer func(){
        r:=recover()
        if (r == nil){
            t.Errorf("Divide should throw exception")
        }
    }()
	got := divide("100","0")
    fmt.Println("got :" ,got)
}*/
func TestDivide2(t *testing.T){
	got, err := divide("100","0")
	fmt.Println("err : ",err)
	if (err == nil){
		t.Errorf("Divide should throw exception")
	}
    fmt.Println("got :" ,got)
}