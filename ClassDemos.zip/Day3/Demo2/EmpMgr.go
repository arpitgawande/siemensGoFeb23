package main

import (
	"fmt"
)

type Emp struct {
	Empno  int    `json:"empno"`
	Ename  string `json:"ename"`
	Salary int    `json:"salary"`
}

func (emp Emp) print() {
	fmt.Println("Print EmpNo = ", emp.Empno, " , Ename =", emp.Ename+", Salary = ", emp.Salary)
}

type EmpManager struct {
	emparr []Emp
}

func (empmgr *EmpManager) add(e1 Emp) {
	empmgr.emparr = append(empmgr.emparr, e1)
}
