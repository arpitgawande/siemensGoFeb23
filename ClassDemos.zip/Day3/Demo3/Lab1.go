package main
import (
    "fmt"
    "net/http"
    "os"
	"time"
)

func hello(w http.ResponseWriter, req *http.Request) {
	hn,_ := os.Hostname()
	fmt.Println("..time = ", time.Now())
    fmt.Fprintf(w, "<body bgcolor='cyan'><h1 >Hello World for Siemens !!!!</h1><h2>executed on server "+hn +"</h2></body>")
}

func main() {
    http.HandleFunc("/", hello) 
    fmt.Println("starting server on 8090")
    http.ListenAndServe(":8090", nil)
}