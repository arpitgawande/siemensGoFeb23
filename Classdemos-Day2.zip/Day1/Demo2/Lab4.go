package main
import (
	"fmt"
 	//"strconv"
)

type Emp struct {
	Empno  int 
	Ename  string 
	Salary int 
}
func (emp *Emp) incrSal(percent int){
	emp.Salary += emp.Salary* percent/100
}
func (emp Emp) print(){
	fmt.Println("Print EmpNo = " , emp.Empno , " , Ename =" , emp.Ename + ", Salary = " , emp.Salary)
}

func main() {

	e1 := Emp{5,"Three", 100}

	fmt.Println(e1)
	e1.incrSal(10)
	fmt.Println(e1)
	e1.print()
}	