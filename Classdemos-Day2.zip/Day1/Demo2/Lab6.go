package main

import (
    "log"
    "os"
    "io"
)

func main() {
    fi, err1 := os.Open(os.Args[1])
    if err1 != nil {
        log.Fatal("FileInput - " , err1)
    }
	defer fi.Close()
    fo, err2 := os.OpenFile(os.Args[2], os.O_RDWR|os.O_CREATE, 0755)
	defer fo.Close()
    if err2 != nil {
        log.Fatal("FileOutput  - ", err2)
    }

    buf := make([]byte, 1024)
    for {
        // read a chunk
        n, err3 := fi.Read(buf)
		
        if err3 != nil && err3 != io.EOF {
            log.Fatal(err3)
        }
        if n == 0 {
            break
        }

        // write a chunk
        if _, err4 := fo.Write(buf[:n]); err4 != nil {
            log.Fatal(err4)
        }
    }

}