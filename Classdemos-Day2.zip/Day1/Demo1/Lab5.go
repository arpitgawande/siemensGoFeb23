package main
import (
	"fmt"
)
func main(){
	add:= add(10,500)
	fmt.Println("Sum = ", add)
}