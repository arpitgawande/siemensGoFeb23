package main
import "fmt"
func add(x, y int) int {
	fmt.Println("Add invoked with ", x, " and ", y)
	//fmt.Println(" Sum = ", (x + y))
	return x + y
}