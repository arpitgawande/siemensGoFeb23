package main
import "fmt"
func adder() func(int) int {
	sum := 0
	fmt.Println("Adder invoked and current sum = ", sum)
	return func(x int) int {
		fmt.Println("in return function and current value of sum = ", sum)
		sum += x
		return sum
	}
}
func main(){
	fref := adder()
	fmt.Println(fref)
	count := fref(10)
	fmt.Println("After passing 10 , current count = " , count)
	count = fref(10)
	fmt.Println("After passing 10 and 10 , current count = " , count)
	count = fref(10)
	fmt.Println("After passing 10 and 10 and 10 , current count = " , count)
}
