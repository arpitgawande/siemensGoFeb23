package main
import "fmt"
func main() {
	f()
    fmt.Println("Returned normally from f.")
}
func f() {
	defer func() {
        if r := recover(); r != nil {
            fmt.Println("Recovered in f", r)
        }
    }()
	fmt.Println("Calling g.")
	g(1)
    fmt.Println("Returned normally from g.")
    
    
}
func g(i int) {
	defer fmt.Println("Defer in g", i)
	if i > 3 {
        fmt.Println("Panicking!")
        panic("Problem")
    }
    fmt.Println("Printing in g", i)
    g(i + 1)
	
}

