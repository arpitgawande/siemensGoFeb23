package main
import "fmt"
func main(){
	defer fmt.Println("hello")
	fmt.Println("world")
	test()
}

func test(){
	defer fmt.Println("test line1")
	fmt.Println("test line2")
}