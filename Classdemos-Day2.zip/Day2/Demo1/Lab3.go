package main
import "fmt"
func main(){
	test1()
	test2()
}
func test1(){
	i := 10;
	defer fmt.Println("world" , i)
	i = 20;
	fmt.Println("hello" , i)
	}
func test2(){
	fmt.Println("counting")
	for i := 0; i < 10; i++ {
		defer fmt.Println(i)
	}
	fmt.Println("done")
	
}