package main

import (
	"fmt"
	"time"
	"strconv"
)

func main() {
	fmt.Println("Starting of main")
	ch := make(chan string,10)
	fmt.Println("ch", ch)
	go read(ch)
	go write(ch)
	time.Sleep(10 * time.Second)
	fmt.Println("Main over...")
}
func read(ch chan string) {
	fmt.Println("Reading Started")
	v := <-ch
	fmt.Println("Read from channel - ", v)
	fmt.Println("Reading  Completed1")
	for msg := range ch {
			    fmt.Println("in read " , msg)	
				time.Sleep(time.Millisecond * 300)	
			}	
	fmt.Println("Reading  Completed2")
}
func write(ch chan string) {
	fmt.Println("Writing Started")
	for i:=1;i<16;i++{
		ch <- "str"+ strconv.Itoa(i)
		fmt.Println("Writing " , i)
	}

	fmt.Println("Writing Completed")
}
