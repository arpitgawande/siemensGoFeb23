package main
import (
	"fmt"
	"time"
)

func main(){
	fmt.Println("Starting of main")
	go print("h")
	go print("w")
	fmt.Println("Ending of main")
	for {}
}

func read(){
	for i:=1;i<50;i++{
		fmt.Print(str , ":" , i , "   ")
		if i % 5 == 0{
			time.Sleep(1 * time.Second)
		}
	}
}