//create table emp (empno numeric primary key, ename varchar(20), salary numeric)
package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
)

func main() {
	db, err := sql.Open("mysql",
		"admin:MyPassword@tcp(database-1.cxmg6nnxkwnv.us-east-1.rds.amazonaws.com:3306)/mydb")
	if err != nil {
		panic(err)
	}
	fmt.Println("Connection Established ", db)
	rows, err := db.Query("insert into emp values (22,'BBB',22000)")
	fmt.Println("Inserted ")
	fmt.Println(rows)
	if err != nil {
		panic(err)
	}
}
