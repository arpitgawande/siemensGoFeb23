package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"siemensdemo/dblib"
)

var empmgr mylib.EmpManager
func Emphandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println(r.Method)
	if r.Method == "GET" {
		barr, _ := json.Marshal(empmgr.List())
		fmt.Fprintln(w, string(barr))
	}
	if r.Method == "POST" {
		fmt.Fprintln(w, "POST Request invoked ")
		emp := mylib.Emp{}
		decoder := json.NewDecoder(r.Body)
		decoder.Decode(&emp)
		fmt.Println(emp)
		empmgr.Insert(emp)
	}/*
	if r.Method == "PUT" {
		fmt.Fprintln(w, "PUT Request invoked ")
		emp := mylib.Emp{}
		decoder := json.NewDecoder(r.Body)
		decoder.Decode(&emp)
		fmt.Println("Modifying ", emp)
	}
	if r.Method == "DELETE" {
		fmt.Fprintln(w, "DELETE Request invoked ")
		fmt.Println("URL " , r.URL)
	} */
}

func main() {
	empmgr = mylib.EmpManager{}
	
	http.HandleFunc("/emps", Emphandler)
	
	log.Fatal(http.ListenAndServe(":8080", nil))

}
