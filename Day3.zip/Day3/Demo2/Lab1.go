package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"
)

var empmgr EmpManager
func Emphandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println(r.Method)
	if r.Method == "GET" {
		barr, _ := json.Marshal(empmgr.emparr)
		fmt.Fprintln(w, string(barr))
	}
	if r.Method == "POST" {
		fmt.Fprintln(w, "POST Request invoked ")
		fmt.Println(w)
		emp := Emp{}
		decoder := json.NewDecoder(r.Body)
		decoder.Decode(&emp)
		fmt.Println(emp)
		empmgr.add(emp)
	}
	if r.Method == "PUT" {
		fmt.Fprintln(w, "PUT Request invoked ")
		fmt.Println(w)
		emp := Emp{}
		decoder := json.NewDecoder(r.Body)
		decoder.Decode(&emp)
		fmt.Println("Modifying ", emp)
	}
	if r.Method == "DELETE" {
		fmt.Fprintln(w, "DELETE Request invoked ")
		fmt.Println("URL " , r.URL)
	}
}

func main() {
	empmgr = EmpManager{}
	for i := 1; i < 2; i++ {
		emp := Emp{i, "Nameof" + strconv.Itoa(i), i * 1000}
		empmgr.add(emp)
	}

	http.HandleFunc("/emps", Emphandler)
	
	log.Fatal(http.ListenAndServe(":8080", nil))

}
