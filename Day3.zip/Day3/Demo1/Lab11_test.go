package main

import "testing"
//import "fmt"

func BenchmarkAdd(b *testing.B) {
	// run the Fib function b.N times
	for n := 0; n < b.N; n++ {
			add(10,n+10)
	}}
