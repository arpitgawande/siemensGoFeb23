package main
import (
	"fmt"
	"strconv"
	"errors"
)

func add(a,b int) int {
	fmt.Println("Add invoked with " , a, ", ", b)
	return a+b
}
func divide(s1, s2 string) (int, error){

	no1,err1:= strconv.Atoi(s1)
	if (err1 != nil) {
		return 0, errors.New("Argument one invalid")
	}
	no2,err2:=strconv.Atoi(s2)
	if (err2 != nil){
		return 0,  errors.New("Argument two invalid")
	}
	if (no2 == 0){
		return 0,  errors.New("Argument two should be nonzero")
	}
	return no1/no2, nil
}
func main(){
	fmt.Println("Main " , add(10,40))
}